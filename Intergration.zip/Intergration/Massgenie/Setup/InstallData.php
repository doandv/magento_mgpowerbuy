<?php
namespace Intergration\Massgenie\Setup;

use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Integration\Model\ConfigBasedIntegrationManager;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\App\Bootstrap;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;
use Zend\Json\Json; 

class InstallData implements InstallDataInterface
{
    private $integrationManager;
    private $httpClient;
    private $storeManager;
    private $scopeConfig;
    private $logger;

    public function __construct(
        ConfigBasedIntegrationManager $integrationManager, 
        \Zend\Http\Client $httpClient,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        ScopeConfigInterface $scopeConfig,
        \Psr\Log\LoggerInterface $logger)
    {
        $this->integrationManager = $integrationManager;
        $this->httpClient = $httpClient;   
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->logger = $logger;
    }

    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        $bootstrap = Bootstrap::create(BP, $_SERVER);
        $objectManager = $bootstrap->getObjectManager();

        //Set your Data
        $name = 'Integration_Massgenie';
        $email = 'doandv@massgenie.com';
        $callbackUrl = "http://localhost:3110/magento/CallBackMagento"; // "http://123.30.149.87:5555/magento-api/Integration";
        $identityUrl = "http://localhost:3110/magento";
        $endpointUrl = 'http://123.30.149.87:5555/magento-api/update-seller-account-info';

        // Code to check whether the Integration is already present or not
        $integrationExists = $objectManager->get('Magento\Integration\Model\IntegrationFactory')->create()->load($name,'name')->getData();
        if(empty($integrationExists)){
            $integrationData = array(
                'name' => $name,
                'email' => $email,
                'status' => '0',
                'endpoint' => $callbackUrl,
                'identity_link_url' => $identityUrl,
                'setup_type' => '0'
            );

            try{
                // Create Integration
                $integrationFactory = $objectManager->get('Magento\Integration\Model\IntegrationFactory')->create();
                $integration = $integrationFactory->setData($integrationData);
                $integration->save();
                $integrationId = $integration->getId();
                $consumerName = 'Integration' . $integrationId;

                // Create consumer
                $oauthService = $objectManager->get('Magento\Integration\Model\OauthService');
                $consumer = $oauthService->createConsumer(['name' => $consumerName]);
                $consumerId = $consumer->getId();
                $integration->setConsumerId($consumer->getId());
                $integration->save();

                // Grant permission
                $authrizeService = $objectManager->get('Magento\Integration\Model\AuthorizationService');
                $authrizeService->grantAllPermissions($integrationId);

                // Activate and Authorize
                // $token = $objectManager->get('Magento\Integration\Model\Oauth\Token');
                // $uri = $token->createVerifierToken($consumerId);
                // $token->setType('access');
                // $token->save();

                // call back save data to MG
                $this->logger->log('DEBUG', 'storeWebsites', array('storeWebsites' => "12312"));
                $storeWebsites = $this->storeManager->getWebsites();
                $this->logger->log('DEBUG','storeWebsites', array('storeWebsites' => json_encode($storeWebsites)));
                $email = $this->scopeConfig->getValue('trans_email/ident_support/email',ScopeInterface::SCOPE_STORE);
                $consumerData = $consumer->getData();
                //$tokenData = $token->getData();
                $this->logger->log('DEBUG', 'consumerData', array('consumerData' => json_encode($consumerData)));
                foreach($storeWebsites as $website) {
                    $this->httpClient->setUri($endpointUrl);
                    $this->httpClient->setMethod(\Zend\Http\Request::METHOD_POST); 
                    $this->httpClient->setHeaders([
                        'Accept' => 'application/json',
                    ]);
                    $shop_guid = $this->Guid();
                    $websiteId = $website["website_id"];
                    $jsonData = '{
                        "ShopName": "' . $shop_guid . '",
                        "SellerEmail": "' . $email . '",
                        "ConsumerKey": "' . $consumerData['key'] . '",
                        "ConsumerSecret": "' . $consumerData['secret'] .'"
                    }';

                    $this->httpClient->setRawBody($jsonData);
                    $this->httpClient->setEncType('application/json');
                    $this->httpClient->send();
                    $response = $this->httpClient->getResponse()->getBody();
                    $this->logger->log('DEBUG', 'storeWebsites', array('storeWebsites' => json_encode($response)));
                    $responseJson = json_decode(utf8_decode($response));
                    if(!empty($responseJson) && $responseJson->isSuccess == true) {
                        $this->insertShopGuid($shop_guid, $websiteId);
                    }
                }
                
            } catch(Exception $e){
                $this->logger->log('ERROR','error', array('error' => $e)); 
            }
        }
        $setup->endSetup();
    }

    public function Guid()
    {
        return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    public function insertShopGuid(string $shop_guid = '', int $websiteId = 0)
    {
        $this->_resources = \Magento\Framework\App\ObjectManager::getInstance()
            ->get('Magento\Framework\App\ResourceConnection');
        $connection= $this->_resources->getConnection();

        $keyConfig = "shop_guid_web_" . $websiteId;
        $themeTable = $this->_resources->getTableName('mg_config_data');
        $sql = "DELETE FROM " . $themeTable . " WHERE key_config = '" . $keyConfig . "';";
        $connection->query($sql);
        $sql = "INSERT INTO " . $themeTable . "(key_config, value) VALUES ('" . $keyConfig . "', '" . $shop_guid . "')";
        $connection->query($sql);
    }
}




